import { LightningElement,api } from 'lwc';

export default class LoadRecord1 extends LightningElement {
    @api recordId;
}