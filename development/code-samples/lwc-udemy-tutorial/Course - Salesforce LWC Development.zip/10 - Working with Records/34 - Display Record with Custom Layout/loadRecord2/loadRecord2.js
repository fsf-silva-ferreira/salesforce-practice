import { LightningElement,api } from 'lwc';

export default class LoadRecord2 extends LightningElement {
    @api recordId;
}