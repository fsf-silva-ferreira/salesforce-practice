import { LightningElement,api } from 'lwc';

export default class EditRecord1 extends LightningElement {
    @api recordId;
    
}