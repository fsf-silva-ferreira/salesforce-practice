import { LightningElement } from 'lwc';

export default class CreateRecord1 extends LightningElement {}