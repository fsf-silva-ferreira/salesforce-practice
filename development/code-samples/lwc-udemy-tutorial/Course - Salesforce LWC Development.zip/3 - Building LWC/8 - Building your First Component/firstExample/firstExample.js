import { LightningElement } from 'lwc';

export default class FirstExample extends LightningElement {
    
}