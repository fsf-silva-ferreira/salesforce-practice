import { LightningElement } from 'lwc';

export default class IfElseExample extends LightningElement {
    something=false;
}